International Journal of Computer Applications (IJCA)
--------------------------------------------------------

The following files are available in the LatexSubmissionGuide-IJCA.zip archive:

Submission Guide.pdf        	- This is the PDF file of Author Guide for Template
ijcaArticle.cls           	- This is the LaTeX2e class file of IJCA Article
ijcaArticle.bst           	- This is the bibliography style file of IJCA Article
Template.tex       		- LaTeX document of sample
Submission Guide.pdf  		- This is the PDF file of sample LaTeX document of Template
BibTex-Sample.bib       	- Bibliography file for sample
IJCA-Sample-image.pdf 		- Graphics file used for pdflatex sample


Happy TeXing!!!

Editor IJCA